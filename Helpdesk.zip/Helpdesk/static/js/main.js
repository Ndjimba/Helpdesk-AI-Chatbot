//runs after all resources are loaded
$(document).ready(function() {
  doBlast("font", "word");
});